#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    cronos = new QTimer(this);

    contador = 0;
    ui->lcdNumber->setDigitCount(5);
    ui->lcdNumber->display(contador);
    // SpinBox: rango y paso cómodos; valor por defecto 1000 ms
    ui->spinBox->setRange(50, 2000);
    ui->spinBox->setSingleStep(50);
    ui->spinBox->setMaximum(1000);
    ui->spinBox->setValue(1000);

    // Conexión del temporizador al bucle principal
    connect(cronos, &QTimer::timeout, this, &MainWindow::funcion_loop);
    // Play: inicia con el periodo actual del SpinBox
    connect(ui->play, &QPushButton::clicked, this, [=]() {
        cronos->start(ui->spinBox->value());
    });
    // Pausa: detiene sin reiniciar el conteo
    connect(ui->pausa, &QPushButton::clicked, this, [=]() {
        cronos->stop();
    });

    // Stop: detiene y reinicia a cero
    connect(ui->stop, &QPushButton::clicked, this, [=]() {
        cronos->stop();
        contador = 0;
        ui->lcdNumber->display(contador);
    });
    // Cambiar periodo: sólo si el timer está activo
    connect(ui->spinBox,
            qOverload<int>(&QSpinBox::valueChanged),
            this,
            [=](int ms){
                if (cronos->isActive()) cronos->start(ms);
            });


    // Crear series de datos para temperatura y humedad
            serieTemperatura = new QLineSeries();
    serieTemperatura->setName("Temperatura °C");
    serieTemperatura->setColor(Qt::red);
    serieHumedad = new QLineSeries();
    serieHumedad->setName("Humedad %");
    serieHumedad->setColor(Qt::blue);

    grafico = new QChart();
    grafico->addSeries(serieTemperatura); // Agregar serie temperatura
    grafico->addSeries(serieHumedad); // Agregar serie humedad
    grafico->setTitle("Temperatura y Humedad en Tiempo Real");
    grafico->setAnimationOptions(QChart::SeriesAnimations);

    // Crear y configurar ejes
    ejeX = new QValueAxis();
    ejeYTemperatura = new QValueAxis(); // Eje Y para temperatura
    ejeYHumedad = new QValueAxis(); // Eje Y para humedad
    ejeX->setTitleText("Tiempo (segundos)");
    ejeYTemperatura->setTitleText("Temperatura (°C)");
    ejeYHumedad->setTitleText("Humedad (%)");
    // Rangos típicos para cada variable
    ejeX->setRange(0, 60);
    ejeYTemperatura->setRange(-10, 50); // Rango típico temperatura
    ejeYHumedad->setRange(0, 100); // Rango típico humedad

    // Asociar ejes al gráfico y series
            grafico->addAxis(ejeX, Qt::AlignBottom);
    grafico->addAxis(ejeYTemperatura, Qt::AlignLeft); // Eje izquierdo: temperatura
    grafico->addAxis(ejeYHumedad, Qt::AlignRight); // Eje derecho: humedad
    // Conectar serie de temperatura a sus ejes
    serieTemperatura->attachAxis(ejeX);
    serieTemperatura->attachAxis(ejeYTemperatura);
    // Conectar serie de humedad a sus ejes
    serieHumedad->attachAxis(ejeX);
    serieHumedad->attachAxis(ejeYHumedad);

    ui->widget->setChart(grafico);
    ui->widget->setRenderHint(QPainter::Antialiasing);
    // Inicializar contador para eje X
    contadorX = 0;


    // Configurar comboBox de puertos
    manejarPuertosSeriales(ui->comboBox, 115200);
    // Conectar señal a slot para manejar líneas recibidas
    connect(this, &MainWindow::serialLineaRecibida,
            this, &MainWindow::onSerialLineaRecibida);


}

MainWindow::~MainWindow()
{
    // Limpiar comunicación serial
        if (serialActual) {
        if (serialActual->isOpen())
            serialActual->close();
        delete serialActual;
        serialActual = nullptr;
    }
    delete ui;
}

void MainWindow::funcion_loop()
{
    ++contador;
    ui->lcdNumber->display(contador);

    // === NUEVO: ACTUALIZAR GRÁFICO CON DOS SERIES ===
    if (ui->checkBox->isChecked()) {
        // Generar datos aleatorios simulados para ambas series
        double temperaturaF = QRandomGenerator::global()->bounded(35.0); // 15-35°C
        double humedadF = QRandomGenerator::global()->bounded(90.0); // 30-90%
        // Agregar puntos a ambas series
        serieTemperatura->append(contadorX, temperaturaF);
        serieHumedad->append(contadorX, humedadF);
        // Mover ventana de visualización si es necesario
        if (contadorX > ejeX->max()) {
            ejeX->setRange(contadorX - 60, contadorX);
        }
        contadorX++;
    }
    else{
        // === MODO REAL: Enviar comando por puerto serial ===
        if (serialActual && serialActual->isOpen()) {
            QJsonObject comando;
            comando["sensor"] = "dht22";
            comando["pin"] = 4;

            QJsonDocument doc(comando);
            QString comandoStr = doc.toJson(QJsonDocument::Compact) + "\n";

            serialActual->write(comandoStr.toUtf8());
            qDebug() << "Comando enviado:" << comandoStr.trimmed();
        }
        // NOTA: Los datos reales vendrán asincrónicamente desde onSerialLineaRecibida
    }
}

void MainWindow::manejarPuertosSeriales(QComboBox *comboBox, int baud)
{
    if (!comboBox) {
        qWarning() << "Debes pasar un QComboBox válido.";
        return;
    }

    // --- Poblar puertos ---
    auto poblarPuertos = [comboBox]() {
        comboBox->blockSignals(true);
        comboBox->clear();
        comboBox->addItem("Seleccionar puerto", QVariant());

        const QList<QSerialPortInfo> puertos = QSerialPortInfo::availablePorts();
        for (const QSerialPortInfo &info : puertos) {
            const QString nombre = info.portName();
            const QString desc   = info.description().isEmpty() ? "Sin descripción" : info.description();
            const QString texto  = QString("%1 — %2").arg(nombre, desc);
            comboBox->addItem(texto, nombre);
        }
        comboBox->blockSignals(false);
    };
    poblarPuertos();

    QObject::disconnect(comboBox, nullptr, this, nullptr);

    QObject::connect(comboBox, QOverload<int>::of(&QComboBox::currentIndexChanged),
                     this,
                     [this, comboBox, baud](int idx) {
                         if (idx <= 0) {
                             if (serialActual && serialActual->isOpen()) {
                                 QString nombre = serialActual->portName();
                                 qDebug() << "Cerrando puerto:" << nombre;
                                 serialActual->close();
                                 QMessageBox::information(this, "Desconectado",
                                                          "Se ha desconectado el puerto " + nombre);
                             }
                             if (serialActual) {
                                 serialActual->deleteLater();
                                 serialActual = nullptr;
                             }
                             return;
                         }

                         const QString nombrePuerto = comboBox->currentData().toString();

                         if (serialActual && serialActual->isOpen()) {
                             qDebug() << "Cerrando puerto previo:" << serialActual->portName();
                             serialActual->close();
                             serialActual->deleteLater();
                             serialActual = nullptr;
                         }

                         serialActual = new QSerialPort(this);
                         serialActual->setPortName(nombrePuerto);
                         serialActual->setBaudRate(baud);
                         serialActual->setDataBits(QSerialPort::Data8);
                         serialActual->setParity(QSerialPort::NoParity);
                         serialActual->setStopBits(QSerialPort::OneStop);
                         serialActual->setFlowControl(QSerialPort::NoFlowControl);

                         if (!serialActual->open(QIODevice::ReadWrite)) {
                             qWarning() << "No se pudo abrir" << nombrePuerto << ":" << serialActual->errorString();
                             QMessageBox::warning(this, "Error",
                                                  "No se pudo abrir el puerto " + nombrePuerto + "\n" +
                                                      serialActual->errorString());
                             serialActual->deleteLater();
                             serialActual = nullptr;

                             comboBox->blockSignals(true);
                             comboBox->setCurrentIndex(0);
                             comboBox->blockSignals(false);
                             return;
                         }

                         qDebug() << "Conexión OK en" << nombrePuerto;

                         QMessageBox::information(this, "Conectado",
                                                  "Se ha conectado exitosamente al puerto " + nombrePuerto);

                         connect(serialActual, &QSerialPort::readyRead,
                                 this, &MainWindow::onReadyRead,
                                 Qt::UniqueConnection);
                     });
}


void MainWindow::onReadyRead()
{
    if (!serialActual) return;
    while (serialActual->canReadLine()) {
        const QByteArray datos = serialActual->readLine().trimmed();
        emit serialLineaRecibida(QString::fromUtf8(datos));
    }
}

void MainWindow::onSerialLineaRecibida(const QString &linea)
{
    // Ejemplo de respuesta: {"ok":true,"temp":25.5,"humedad":65.8}
    const QByteArray bytes = linea.toUtf8();
    QJsonParseError perr;
    const QJsonDocument doc = QJsonDocument::fromJson(bytes, &perr);
    if (perr.error != QJsonParseError::NoError || !doc.isObject()) {
        qWarning() << "JSON inválido:" << perr.errorString() << "en" << linea;
        return;
    }

    const QJsonObject obj = doc.object();

    // (Opcional) valida "ok"
    if (obj.contains("ok") && obj.value("ok").isBool() && !obj.value("ok").toBool()) {
        qWarning() << "Mensaje con ok=false";
        return;
    }

    bool datosValidos = false;

    // Validar que AMBOS datos existen
    if (obj.contains("temp") && obj.value("temp").isDouble() &&
        obj.contains("humedad") && obj.value("humedad").isDouble()) {

        temperatura = obj.value("temp").toDouble();
        humedad = obj.value("humedad").toDouble();
        datosValidos = true;

        ui->displayTemperatura->display(QString::number(temperatura, 'f', 1));
        ui->displayHumedad->display(QString::number(humedad, 'f', 1));
    }

    // Solo graficar si estamos en modo REAL (no simulado) y hay datos válidos
    if (!ui->checkBox->isChecked() && datosValidos) {
        serieTemperatura->append(contadorX, temperatura);
        serieHumedad->append(contadorX, humedad);

        // Mover ventana de visualización si es necesario
        if (contadorX > ejeX->max()) {
            ejeX->setRange(contadorX - 60, contadorX);
        }
        contadorX++;
    }
}
