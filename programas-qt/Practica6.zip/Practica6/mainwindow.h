#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QtCharts/QtCharts>
#include <QtCharts/QLineSeries>
#include <QtCharts/QChartView>
#include <QtCharts/QValueAxis>
#include <QRandomGenerator>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonObject>
#include <QDebug>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void manejarPuertosSeriales(QComboBox *comboBox, int baud = 115200);
    // Acceso al puerto por si quieres escribir desde otros métodos
    QSerialPort* puertoSerial() const { return serialActual; }

signals:
    // ESTA es la señal que emites cuando llega una línea completa
    void serialLineaRecibida(const QString &linea);

private slots:
    void funcion_loop();
    void onReadyRead(); // slot interno para leer del puerto
    void onSerialLineaRecibida(const QString &linea); // tu handler opcional

private:
    Ui::MainWindow *ui;
    QTimer *cronos;
    int contador = 0;
    // Nuevas variables para el gráfico
    // Variables para el gráfico con dos series
    // Nuevas variables para el gráfico
    QChart *grafico = nullptr;
    QLineSeries* serieTemperatura = nullptr; // Serie para temperatura
    QLineSeries* serieHumedad = nullptr; // Serie para humedad
    QValueAxis* ejeX = nullptr;
    QValueAxis* ejeYTemperatura = nullptr; // Eje Y para temperatura
    QValueAxis* ejeYHumedad = nullptr; // Eje Y para humedad
    int contadorX = 0;

    double temperatura = 0.0;
    double humedad = 0.0;

    QSerialPort *serialActual = nullptr;
};
#endif // MAINWINDOW_H
