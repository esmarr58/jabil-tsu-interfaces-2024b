#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QComboBox>
#include <QDateTime>
#include <QDebug>
#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonObject>
#include <QVariant>        // (opcional, por currentData/ QVariant)
#include <QSerialPortInfo> // redundante si ya está en el .h, no hace daño


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    // API: abre/cierra según selección de un combo ya existente
    void manejarPuertosSeriales(QComboBox *comboBox, int baud = 115200);

    // Acceso al puerto por si quieres escribir desde otros métodos
    QSerialPort* puertoSerial() const { return serialActual; }

signals:
    // ✅ ESTA es la señal que emites cuando llega una línea completa
    void serialLineaRecibida(const QString &linea);

private slots:
    void onReadyRead();                    // slot interno para leer del puerto
    void onSerialLineaRecibida(const QString &linea); // tu handler opcional

    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui = nullptr;
    QSerialPort *serialActual = nullptr;
};

#endif // MAINWINDOW_H
